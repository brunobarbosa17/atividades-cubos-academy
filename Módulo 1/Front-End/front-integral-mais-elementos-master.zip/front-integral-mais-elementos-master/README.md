![](https://i.imgur.com/xG74tOh.png)

# Conhecendo mais elementos

## Exercícios de classe 🏫

1. Receita de lasanha 2.0
2. WikiCat


Preencha a checklist para finalizar o exercício:
-   [ ] Forkar o repositório

###### tags: `módulo 1` `front-end` `HTML`
