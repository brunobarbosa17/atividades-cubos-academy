![](https://i.imgur.com/xG74tOh.png)

# Introdução ao CSS

## Exercícios de classe 🏫

1. Receita de lasanha 3.0
2. LoremIpsum


Preencha a checklist para finalizar o exercício:
-   [ ] Forkar o repositório

###### tags: `módulo 1` `front-end` `HTML` `CSS` 
