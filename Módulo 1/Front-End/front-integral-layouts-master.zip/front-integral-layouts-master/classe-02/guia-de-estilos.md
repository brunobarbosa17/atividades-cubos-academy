## Cores

### Primárias

Dark cyan: hsl(185, 75%, 39%)
Very dark desaturated blue: hsl(229, 23%, 23%)
Dark grayish blue: hsl(227, 10%, 46%)

### Neutras

Dark gray: hsl(0, 0%, 59%)

## Tipografia

### Body Copy

- Font size (nome e informações): 18px

### Fonte

- Family: [Kumbh Sans](https://fonts.google.com/specimen/Kumbh+Sans)
- Weights: 400, 700
