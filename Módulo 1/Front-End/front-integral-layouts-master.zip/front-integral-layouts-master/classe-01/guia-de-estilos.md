## Cores

### Primárias

- Cyan: hsl(179, 62%, 43%)
- Bright Yellow: hsl(71, 73%, 54%)

### Neutras

- Light Gray: hsl(204, 43%, 93%)
- Grayish Blue: hsl(218, 22%, 67%)

## Tipografia

### Body Copy

- Font size: 16px

### Fonte

- Family: [Karla](https://fonts.google.com/specimen/Karla)
- Weights: 400, 700