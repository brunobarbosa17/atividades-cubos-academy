![](https://i.imgur.com/xG74tOh.png)

# Introdução ao front-end

## Exercícios de classe 🏫

1. Lista de supermercado
2. Receita de lasanha
3. Top 3 filmes favoritos

Preencha a checklist para finalizar o exercício:
-   &#9989; Forkar o repositório

###### tags: `módulo 1` `front-end` `HTML`
