![](https://i.imgur.com/xG74tOh.png)

# Back-end | Objetos e Funções

## Exercícios de classe 🏫

01. Sistema de correção de provas
02. Carro

## Exercícios extras 🌟

03. Carrinho de um e-commerce
04. Sistema de transações bancárias

Preencha a checklist para fazer os exercícios:

-   [ ] Fazer o fork do repositório para sua conta
-   [ ] Executar `git clone` do seu fork no terminal para clonar o repositório, ou clonar de outra maneira
-   [ ] Após fazer e commitar todos os exercícios fazer o `git push` para seu fork
-   [ ] Copiar a url do seu fork e enviar na plataforma

###### tags: `módulo 1` `exercício de classe` `lógica` `matemática` `nodeJS` `funções` `objetos` `métodos`
