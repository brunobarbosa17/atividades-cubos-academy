let po = 1000
let x = 4
let t = 100
let expoente = t/7

let P = (po * Math.pow(x,expoente))

console.log(P)