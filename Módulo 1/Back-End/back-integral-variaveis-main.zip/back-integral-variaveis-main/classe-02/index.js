let F = 73
let C = (F-32) * 5/9

console.log(Math.round(C))