let distPercorrida = 25
let tempo = 20

let velocidade = (distPercorrida / tempo * 3.6)

console.log(velocidade + "km/h")