let a = 2, b = 3, c= 4
let delta = Math.pow(b,2) - 4 * a * c

console.log(delta)