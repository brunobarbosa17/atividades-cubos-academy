let a = 27 
let b =  123
let c = 50
let d = b*c / a

console.log(Math.round(d))