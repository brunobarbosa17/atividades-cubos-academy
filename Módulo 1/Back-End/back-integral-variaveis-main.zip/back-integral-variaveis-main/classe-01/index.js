let P = 76, a = 1.79
let imc = (P / (Math.pow(a,2)))

console.log(imc.toFixed(1))