let n = 5
let soma = (n - 2) * 180

let angulo = soma / n

console.log(angulo)