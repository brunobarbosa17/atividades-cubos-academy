let x1 = 1
let x2 = 1
let y1 = 1
let y2 = 4

let a1 = Math.pow(x2-x1,2)
let a2 = Math.pow(y2-y1,2)

let d = Math.sqrt(a1+a2)

console.log(d)