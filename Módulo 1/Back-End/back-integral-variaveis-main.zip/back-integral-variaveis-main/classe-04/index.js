let i = 0.125
let C = 1000
let t = 5

let M = C * Math.pow((1+i), t);

console.log(Math.round(M))