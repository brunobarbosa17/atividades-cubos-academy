let pi = 3.1415926535898
let R = 5
let C = 2 * pi * R;
let area = 3.1415926535898 * Math.pow(R, 2)
console.log(`A circunferência do círculo é: ${Math.round(C)} e a área é: ${area}`)