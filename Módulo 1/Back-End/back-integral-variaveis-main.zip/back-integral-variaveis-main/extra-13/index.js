let pi = 3.14
let r = 2 // raio
let h = 3// altura
let lateral = 2 * pi * Math.pow(r,2)
let base = 2 * pi * Math.pow(r,2)
let total = lateral + 2*base

console.log(total)