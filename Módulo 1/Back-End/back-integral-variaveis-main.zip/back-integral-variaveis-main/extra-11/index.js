let r = 5


let volume = (4/3) * 3.14 * Math.pow(r,3)

console.log(volume.toFixed(2))