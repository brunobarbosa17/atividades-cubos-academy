const nomes = ['Juninho', 'Léo', 'Guido', 'Dina', 'Vitinho', 'Nanda'];
const tamanhoDoGrupo = 4;

function separar(array, qntd) {
    if (array.length % qntd == 2) {
        for (let i = 0; i < n; i++) {
          
        }
    } 
}

/*ESSA AQUI EU ME EMBOLEI*/