![](https://i.imgur.com/xG74tOh.png)

# Exercícios | Sort e outros métodos

## Exercícios de classe 🏫

1. Ordenando Arrays
2. Filtrar maior string
3. Filtrar maior número
4. Verificando limite de caracters
5. Validando lista de compras
6. Validação de numeros pares
7. Filtro e validação de usuários

---

Preencha a checklist para fazer os exercícios:

-   [ ] Fazer o fork do repositório para sua conta
-   [ ] Executar `git clone` do seu fork no terminal para clonar o repositório, ou clonar de outra maneira
-   [ ] Após fazer e commitar todos os exercícios fazer o `git push` para seu fork
-   [ ] Copiar a url do seu fork e enviar na plataforma

###### tags: `módulo 1` `exercício de classe` `lógica` `matemática` `nodeJS`
