![](https://i.imgur.com/xG74tOh.png)

# Exercícios - Arrays e Loops

## Exercícios de classe 🏫

1. Soma total
2. Contando letras
3. Encontre o 10
4. Múltiplos de 3
5. Filtrando apenas os pares
6. Soma dos pares
7. Filtrando nomes com a letra A
8. Encontrando o maior

## Exercícios extras 🌟

9. Fila de pedidos
10. Para pensar um pouco mais
11. Filtrando números
12. Fila do banco
13. Verificando disjuntores
14. Imprima os menores
15. Separando pares de ímpares

---

Preencha a checklist para fazer os exercícios:

-   [ ] Fazer o fork do repositório para sua conta
-   [ ] Executar `git clone` do seu fork no terminal para clonar o repositório, ou clonar de outra maneira
-   [ ] Após fazer e commitar todos os exercícios fazer o `git push` para seu fork
-   [ ] Copiar a url do seu fork e enviar na plataforma

###### tags: `módulo 1` `exercício de classe` `lógica` `matemática` `nodeJS`
