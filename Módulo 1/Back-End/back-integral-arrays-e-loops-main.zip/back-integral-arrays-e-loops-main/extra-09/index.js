const filaDePedidos = ["pedido 12", "pedido 13", "pedido 14"];

filaDePedidos.push('pedido 15')
filaDePedidos.shift()

console.log(filaDePedidos)