let num = 0

while (num <= 500) {
    console.log(num)
    num += 3
}