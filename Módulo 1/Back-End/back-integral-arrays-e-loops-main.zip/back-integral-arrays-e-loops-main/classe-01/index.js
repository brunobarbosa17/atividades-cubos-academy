const numeros = [2, 3, 4, 6];
let soma=0
for(numero of numeros) {
    soma += numero
}

console.log(soma)