const numeros = [10, 987, -886, 0, 12, 199, -45, -67];

const positivos = numeros.filter(x => x > 0)

console.log(positivos)