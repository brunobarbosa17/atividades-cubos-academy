const frutas = ["Manga", "UVA", "abacaxi", "banaNA", "MAçã"];

frutas = frutas.split(' ')

console.log(frutas)

