const alturaEmCm = 185;

//seu código aqui
