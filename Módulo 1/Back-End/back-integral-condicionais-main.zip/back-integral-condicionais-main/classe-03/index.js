const ladoA = 9;
const ladoB = 9;

if (ladoA === ladoB) {
    console.log('SIM')
} else {
    console.log('NAO')
}