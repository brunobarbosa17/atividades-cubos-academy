![](https://i.imgur.com/xG74tOh.png)

# Back-end | Condicionais

## Exercícios de classe 🏫

01. Pedra, papel ou tesoura
02. Par ou ímpar
03. Dominó
04. Dando nome as pedras
05. Peneira de Vôlei 
06. Definindo as posições
07. Isenção de impostos
08. Montanha Russa Muito Assustadora

## Exercícios extras 🌟

09. Transformar nota em conceito
10. Identificando caracteres
11. Valor da parcela do Sucesso Compartilhado
12. Dia da Semana
13. Compra com Desconto
14. Controle de Consumo de Água Ingerida
15. Nome para Exibição
16. Rematrícula Escolar
17. Extrato de compra online

---

Preencha a checklist para fazer os exercícios:

-   [ ] Fazer o fork do repositório para sua conta
-   [ ] Executar `git clone` do seu fork no terminal para clonar o repositório, ou clonar de outra maneira
-   [ ] Após fazer e commitar todos os exercícios fazer o `git push` para seu fork
-   [ ] Copiar a url do seu fork e enviar na plataforma

###### tags: `módulo 1` `exercícios` `lógica` `matemática` `nodeJS`
