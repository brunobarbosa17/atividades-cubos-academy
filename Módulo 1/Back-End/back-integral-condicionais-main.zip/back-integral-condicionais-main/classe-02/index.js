const jogada1 = 5;
const jogada2 = 3;
const x = jogada1+jogada2;

if (x % 2 == 0) {
    console.log('par')
} else {
    console.log('impar')
}