const primeiroNome = "Mario";
const sobrenome = "";
const apelido = "";

if(apelido) {
    console.log(apelido)
} else if (sobrenome) {
    console.log (primeiroNome + " " + sobrenome)
} else if (!sobrenome) {
    console.log(primeiroNome)
}